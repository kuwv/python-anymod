# type: ignore
'''Example class to test loading nested.'''


class NestedTest:
    '''Test nested class.'''

    def __init__(self):
        '''Initialize test.'''
        self.key = 'value'
