# type: ignore
'''Example class to test loading.'''


class EntryTest:
    '''Test class.'''

    def __init__(self):
        '''Initialize test.'''
        self.key = 'value'
